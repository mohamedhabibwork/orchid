<div class="nav-tabs-alt">
    <ul class="nav nav-tabs nav-tabs-scroll-bar" role="tablist">
        {!! $navigations !!}
    </ul>
</div>

<div class="table-notification">
    {!! $table !!}
</div>

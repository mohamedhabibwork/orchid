<x-orchid-stream target="screen-state">
    <input type="hidden" name="_state" id="screen-state" value="{{ $state }}">
</x-orchid-stream>

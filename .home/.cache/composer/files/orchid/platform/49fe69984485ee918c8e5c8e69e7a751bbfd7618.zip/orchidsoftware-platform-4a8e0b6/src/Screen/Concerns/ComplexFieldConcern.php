<?php

declare(strict_types=1);

namespace Orchid\Screen\Concerns;

interface ComplexFieldConcern
{
}

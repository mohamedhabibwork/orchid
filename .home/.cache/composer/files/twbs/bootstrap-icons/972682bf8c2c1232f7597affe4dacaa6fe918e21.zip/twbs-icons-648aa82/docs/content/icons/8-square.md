---
title: 8 square
categories:
  - Shapes
tags:
  - number
  - numeral
---

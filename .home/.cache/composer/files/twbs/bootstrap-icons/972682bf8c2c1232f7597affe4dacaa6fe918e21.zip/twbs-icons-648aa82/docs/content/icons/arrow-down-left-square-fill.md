---
title: Arrow down left square fill
categories:
  - Shape Arrows
tags:
  - arrow
  - square
---

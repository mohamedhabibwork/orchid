---
title: Building up
categories:
  - Buildings
tags:
  - company
  - enterprise
  - organization
  - office
  - business
---
